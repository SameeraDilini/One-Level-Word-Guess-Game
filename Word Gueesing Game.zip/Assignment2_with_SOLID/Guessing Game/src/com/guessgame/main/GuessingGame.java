/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.guessgame.main;

import com.guessgame.factory.Logic;
import com.guessgame.factory.ReadFile;
import com.guessgame.factory.ReadFileFactory;
import com.guessgame.factory.test;
import java.io.IOException;
import java.util.Scanner;




/**
 *
 * @author user
 */
public class GuessingGame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

        Logic logic=new Logic();
        logic.GetLogic();

//            for(int i=0;i<3;i++){
//               System.out.println("Level "+i);
//               test logic=new test();
//               logic.GetLogic();
//               Runtime.getRuntime().exec("cls");
//               
//            
//            }
//            
//            System.exit(0);
    }
    
}
