/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.guessgame.factory;

import java.util.Random;

/**
 *
 * @author user
 */
public class GenerateRandomNumber {
    private static final GenerateRandomNumber INSTANCE=new GenerateRandomNumber();
    private static Random r=new Random();
    private static int generateNo=r.nextInt(6)+1;
    
    private GenerateRandomNumber(){
    }
    
    public static int RandomGeneratedNumber(){
        return generateNo;
    } 
    public static Random RandomNumber(){
        return r;
    }
    
    public static GenerateRandomNumber getInstance(){
        return INSTANCE;
    }
}
