/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.guessgame.factory;

/**
 *
 * @author user
 */
public class CheckingWord {
    
    int attemptl=5,attempt2=1;
    boolean invalid=false;
    boolean retry=true;
    
    public void checkingWord(String let,String data){
        String[] letters=CreateLetters.getInstance().createLetters(data);
        String[] dummy=CreateDummy.getInstance().createDummy(data);
        
                do{
                    if(let.length()<2){
                        let=String.valueOf(let.charAt(0));
                        for(int i=0;i<data.length();i++){
                            if(let.equalsIgnoreCase(dummy[i])){
                                letters[i]=let.toUpperCase();
                                invalid=true;
                                retry=false;
                                
                            }
                        }
                        
                     if(invalid==false){
                         --attemptl;
                         System.out.println("Wrong. The Letter '"+let.toString()+"'is not in the word."+"\nYou only have "+attemptl+"chances left.\n");
                         retry=true;
                         
                         if(attemptl==0){
                             System.out.println("Game Over ! The Word is "+data.toString());
                             System.exit(0);
                             
                         }
                     }   
                     
                     boolean hasq=true;
                     for(int i=0;i<data.length();i++){
                         if(letters[i].equals("?")){
                             retry=false;
                             hasq=false;
                         }
                     }
                     
                     if(hasq==true){
                         System.out.println("Congratulations ! The word was "+data.toString());
                         retry=false;
                         System.exit(0);
                     }
                     
                     for(int i=0;i<data.length();i++){
                         System.out.print(letters[i]);
                         retry=false;
                     }
                    }else if(data.equalsIgnoreCase(let)){
                        System.out.println("Correct");
                        retry=false;
                        System.exit(0);
                        
                    }else{
                        --attempt2;
                        System.out.println("Wrong Word  Guess!"+"Your remaining guess is : "+attempt2);
                        retry=true;
                        
                        if(attempt2==0){
                            System.out.println("Game Over!!! ");
                            System.exit(0);
                            
                        }
                    }
                }while(retry);
    }
    
}
