/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.guessgame.factory;

import static com.guessgame.factory.GetUserInput.s;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class GetUserInput {
    static Scanner s=new Scanner(System.in);
    
    public static String getUserInput(){
        
        return s.nextLine();
        
    }
    
}
