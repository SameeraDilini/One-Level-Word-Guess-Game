/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.guessgame.factory;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class ReadWordFile extends ReadFile{

    private static final ReadWordFile INSTANCE=new ReadWordFile();
    private static BufferedReader input=null;
    
    private ReadWordFile(){
    }
    
    @Override
    BufferedReader ReadFile() {
        try {
            input=new BufferedReader(new FileReader("D:\\Semester 7\\OODP\\Assignment\\resources\\Word.txt"));
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ReadWordFile.class.getName()).log(Level.SEVERE, null, ex);
        }
        return input;
    }
    
    public static ReadWordFile getInstance(){
        return INSTANCE;
    }
    
}
