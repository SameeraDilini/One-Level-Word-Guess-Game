/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.guessgame.factory;

import com.guessgame.factory.ReadWordFile;

/**
 *
 * @author user
 */
public class ReadFileFactory {
    public static ReadFile create(String ReadFile) {
        
        if("word".equals(ReadFile)){
            ReadWordFile file = ReadWordFile.getInstance();
            
            return file;
        }

        throw new FileNotFoundException(ReadFile);
    }
}
