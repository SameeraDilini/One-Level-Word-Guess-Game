/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.guessgame.factory;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Random;

/**
 *
 * @author user
 */
public class RandomWord {
     
      String data;
      int ctr=0;
      int generateNo=GenerateRandomNumber.RandomGeneratedNumber();
            
    public  String GenerateRandomWord(BufferedReader in) throws IOException{
    
         while((data=in.readLine())!=null){
                ctr++;
//                System.out.println(data);
                if(ctr==generateNo){
                    break;
                }
                
            }
         in.close();
         return data;
    }
    
    
   
}
