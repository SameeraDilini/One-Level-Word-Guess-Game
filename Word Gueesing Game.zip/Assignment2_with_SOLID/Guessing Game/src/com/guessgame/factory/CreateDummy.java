/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.guessgame.factory;

/**
 *
 * @author user
 */
public class CreateDummy {
    private static final CreateDummy INSTANCE=new CreateDummy();
    private static String[] dummy=new String[100];
    
    private CreateDummy(){
    }
    
    public String[] createDummy(String data){
        for(int i=0;i<data.length();i++){
                dummy[i]=String.valueOf(data.charAt(i));
            }
        return dummy;
    }
    
    public static CreateDummy getInstance(){
        return INSTANCE;
    }
    
}
