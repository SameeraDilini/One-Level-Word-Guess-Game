/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.guessgame.factory;

import java.io.*;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class Logic {
    
     ReadFile file = ReadFileFactory.create("word");
     BufferedReader input=file.ReadFile();
     String[] letters=new String[100];
     String[] dummy=new String[100];
     Random r=GenerateRandomNumber.RandomNumber();
    
     RandomWord randomword=new RandomWord();
     String data;
     int attemptl=5,attempt2=1;
     boolean retry=true;
     String let;

    public Logic() throws IOException {
        this.data = randomword.GenerateRandomWord(input);
    }

    
    
    
    public  void GetLogic(){
        for(int i=0;i<data.length();i++){
                letters[i]=String.valueOf(data.charAt(i));
            }
            
        for(int i=0;i<data.length();i++){
            dummy[i]=String.valueOf(data.charAt(i));
        }
        
        for(int i=0;i<4;i++){
           int gNo=r.nextInt(data.length());
                
            if(letters[gNo].equals("?")){
                i--;
            }else{
               letters[gNo]="?";
            }
               
            }
            
            for(int i=0;i<data.length();i++){
                System.out.print(letters[i]);
            }
            System.out.println("\n");
            System.out.println("Chances Left : "+attemptl);
            
            do{
                System.out.println("\nGuess a Letters : ");
                let=GetUserInput.getUserInput();
                boolean invalid=false;
                do{
                    if(let.length()<2){
                        let=String.valueOf(let.charAt(0));
                        for(int i=0;i<data.length();i++){
                            if(let.equalsIgnoreCase(dummy[i])){
                                letters[i]=let.toUpperCase();
                                invalid=true;
                                retry=false;
                                
                            }
                        }
                        
                     if(invalid==false){
                         --attemptl;
                         System.out.println("Wrong. The Letter '"+let.toString()+"'is not in the word."+"\nYou only have "+attemptl+"chances left.\n");
                         retry=true;
                         
                         if(attemptl==0){
                             System.out.println("Game Over ! The Word is "+data.toString());
                             System.exit(0);
                             
                         }
                     }   
                     
                     boolean hasq=true;
                     for(int i=0;i<data.length();i++){
                         if(letters[i].equals("?")){
                             retry=false;
                             hasq=false;
                         }
                     }
                     
                     if(hasq==true){
                         System.out.println("Congratulations ! The word was "+data.toString());
                         retry=false;
                         System.exit(0);
                     }
                     
                     for(int i=0;i<data.length();i++){
                         System.out.print(letters[i]);
                         retry=false;
                     }
                    }else if(data.equalsIgnoreCase(let)){
                        System.out.println("Correct");
                        retry=false;
                        System.exit(0);
                        
                    }else{
                        --attempt2;
                        System.out.println("Wrong Word Guess!"+"Your remaining guess is : "+attempt2);
                        retry=true;
                        
                        if(attempt2==0){
                            System.out.println("Game Over!!! ");
                            System.exit(0);
                            
                        }
                    }
                }while(retry);
            }while(true);
    }
}
