/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.guessgame.factory;

import java.io.BufferedReader;

/**
 *
 * @author user
 */
public class CreateLetters {
    private static final CreateLetters INSTANCE=new CreateLetters();
    private static String[] letters=new String[100];
    
    private CreateLetters(){
    }
    public String[] createLetters(String data){
        for(int i=0;i<data.length();i++){
                letters[i]=String.valueOf(data.charAt(i));
            }
        return letters;
    }
    
    public static CreateLetters getInstance(){
        return INSTANCE;
    }
}
